<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}
include "../db.php";

$title = "List Available Beds by Branch";
$content = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $branch = $_POST["branch_id"];

    // Run SP
    $result = $conn->query("CALL sp_list_available_beds('$branch')");

    $table = "<table><tr>
    <th>Bed ID</th><th>Room</th><th>Bed #</th><th>Type</th><th>Status</th>
    </tr>";

    while ($r = $result->fetch_assoc()) {
        $table .= "<tr>
            <td>{$r['bed_id']}</td>
            <td>{$r['room_no']}</td>
            <td>{$r['bed_number']}</td>
            <td>{$r['bed_type']}</td>
            <td>{$r['status']}</td>
        </tr>";
    }

    $table .= "</table>";
    $content = $table;

    // REQUIRED: clear stored procedure results
    while ($conn->more_results() && $conn->next_result()) {;}
}
?>

<!DOCTYPE html>
<html>
<head>
<title><?= $title ?></title>
<link rel="stylesheet" href="../style.css">
</head>
<body>

<h1><?= $title ?></h1>
<a href="../index.php"><button>⬅ Back</button></a>

<div class="container-box">
<form method="POST">
    <label>Select Branch</label>
    <select name="branch_id" required>
        <option value="">-- Select --</option>
        <?php
            $res = $conn->query("SELECT * FROM Branch");
            while ($br = $res->fetch_assoc()) {
                echo "<option value='{$br['branch_id']}'>{$br['branch_name']}</option>";
            }
        ?>
    </select>

    <input type="submit" value="Run Procedure">
</form>
</div>

<div class="table-container">
<?= $content ?>
</div>

</body>
</html>
