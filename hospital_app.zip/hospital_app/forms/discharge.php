<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

include "../db.php";

$title = "Discharge Patient";

// Get selected branch (from GET)
$selected_branch = isset($_GET['branch_id']) && $_GET['branch_id'] !== '' 
    ? $_GET['branch_id'] 
    : null;

// =========================================
// BEGIN capturing content for form template
// =========================================
ob_start();
?>

<!-- Branch Filter Form (GET) -->
<form method="GET">
    <label>Filter By Branch</label>
    <select name="branch_id" onchange="this.form.submit()">
        <option value="">-- All Branches --</option>

        <?php
        $bq = $conn->query("SELECT branch_id, branch_name FROM Branch ORDER BY branch_name ASC");
        while ($b = $bq->fetch_assoc()):
        ?>
            <option value="<?= htmlspecialchars($b['branch_id']) ?>"
                <?= ($selected_branch == $b['branch_id']) ? "selected" : "" ?>>
                <?= htmlspecialchars($b['branch_name']) ?>
            </option>
        <?php endwhile; ?>
    </select>
</form>

<br>

<!-- Discharge Form (POST) -->
<form method="POST">

    <!-- Preserve branch selection across POST (URL keeps GET too, but this is extra-safe) -->
    <?php if ($selected_branch !== null): ?>
        <input type="hidden" name="branch_id" value="<?= htmlspecialchars($selected_branch) ?>">
    <?php endif; ?>

    <label>Select Admission to Discharge</label>
    <select name="admission_id" required>
        <option value="">-- Choose Patient --</option>

        <?php
        // We want: only admitted patients, optionally filtered by branch.

        if ($selected_branch !== null) {
            // Use prepared statement WITH branch filter
            $sql = "
                SELECT a.admission_id, p.name
                FROM Admission a
                JOIN Patient p ON p.patient_id = a.patient_id
                JOIN Doctor d ON d.doctor_id = a.doctor_id
                JOIN Branch b ON b.branch_id = d.branch_id
                WHERE a.status = 'Admitted'
                  AND b.branch_id = ?
                ORDER BY p.name ASC
            ";

            // Decide parameter type based on branch_id style
            $param_type = is_numeric($selected_branch) ? "i" : "s";

            $stmt = $conn->prepare($sql);
            $stmt->bind_param($param_type, $selected_branch);
            $stmt->execute();
            $result = $stmt->get_result();
        } else {
            // No branch selected → show all admitted patients
            $sql = "
                SELECT a.admission_id, p.name
                FROM Admission a
                JOIN Patient p ON p.patient_id = a.patient_id
                WHERE a.status='Admitted'
                ORDER BY p.name ASC
            ";
            $result = $conn->query($sql);
        }

        if ($result && $result->num_rows > 0):
            while ($row = $result->fetch_assoc()):
        ?>
                <option value="<?= $row['admission_id'] ?>">
                    <?= htmlspecialchars($row['name']) ?>
                </option>
        <?php
            endwhile;
        else:
        ?>
            <option disabled>(No admitted patients for this branch)</option>
        <?php endif; ?>

    </select>

    <input type="submit" value="Discharge Patient">
</form>

<?php
// ========================
// FORM SUBMISSION HANDLER
// ========================
if ($_SERVER['REQUEST_METHOD'] === "POST") {

    $adm = $_POST['admission_id'];

    // SECURE UPDATE using prepared statement
    $stmt = $conn->prepare("
        UPDATE Admission
        SET status = 'Discharged',
            discharge_date = CURDATE()
        WHERE admission_id = ?
    ");
    $stmt->bind_param("i", $adm);

    if ($stmt->execute()) {
        echo "<div class='success-msg'>Patient discharged successfully!</div>";
    } else {
        echo "<div class='error-msg'>Error: " . htmlspecialchars($stmt->error) . "</div>";
    }
}

$content = ob_get_clean();
include "form_template.php";
