<?php
$title = "High Priority Patients";
include "../db.php";

$result = $conn->query("SELECT * FROM vw_high_priority_patients");

$table = "<table><tr>
<th>Admission ID</th><th>Patient</th><th>Priority</th>
<th>Bed</th><th>Type</th><th>Branch</th><th>Date</th>
</tr>";

while ($r = $result->fetch_assoc()) {
    $table .= "<tr>
        <td>{$r['admission_id']}</td>
        <td>{$r['patient_name']}</td>
        <td>{$r['priority_level']}</td>
        <td>{$r['bed_id']}</td>
        <td>{$r['bed_type']}</td>
        <td>{$r['branch_name']}</td>
        <td>{$r['admission_date']}</td>
    </tr>";
}
$table .= "</table>";

$content = $table;
include "report_template.php";
