<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

include "../db.php";

$title = "Admission History & Monthly Trends";

/* ============================================================
   1) Monthly Admissions Count (Month-Based Trend)
   ============================================================ */
$monthlyResult = $conn->query("
    SELECT 
        DATE_FORMAT(admission_date, '%Y-%m') AS month,
        COUNT(*) AS total_admissions
    FROM Admission
    GROUP BY DATE_FORMAT(admission_date, '%Y-%m')
    ORDER BY month ASC
");

$months = [];
$monthlyCounts = [];

while ($row = $monthlyResult->fetch_assoc()) {
    $months[] = $row['month'];
    $monthlyCounts[] = (int)$row['total_admissions'];
}

/* ============================================================
   2) Full Admission History (Latest 200)
   ============================================================ */
$historyResult = $conn->query("
    SELECT *
    FROM vw_admission_history
    ORDER BY admission_date DESC, admission_id DESC
    LIMIT 200
");

// Start capturing template content
ob_start();
?>

<!-- ============================================================ -->
<!-- (1) Monthly Admissions Trend Chart                            -->
<!-- ============================================================ -->
<div class="chart-container" style="max-width:900px; margin:auto;">
    <h2 style="text-align:center;">Admissions by Month</h2>
    <canvas id="monthlyChart" style="height:260px;"></canvas>
</div>

<br>

<!-- ============================================================ -->
<!-- (2) Detailed Admission History Table                          -->
<!-- ============================================================ -->
<div class="table-container">
    <h2>Recent Admission History (Latest 200)</h2>
    <table>
        <tr>
            <th>Admission ID</th>
            <th>Patient</th>
            <th>Doctor</th>
            <th>Bed</th>
            <th>Branch</th>
            <th>Admit Date</th>
            <th>Discharge Date</th>
            <th>Status</th>
            <th>Diagnosis</th>
        </tr>

        <?php while ($r = $historyResult->fetch_assoc()): ?>
        <tr>
            <td><?= $r['admission_id'] ?></td>
            <td><?= htmlspecialchars($r['patient_name']) ?></td>
            <td><?= htmlspecialchars($r['doctor_name']) ?></td>
            <td><?= $r['bed_id'] ?></td>
            <td><?= $r['branch_name'] ?></td>
            <td><?= $r['admission_date'] ?></td>
            <td><?= $r['discharge_date'] ?></td>
            <td><?= $r['status'] ?></td>
            <td><?= htmlspecialchars($r['diagnosis']) ?></td>
        </tr>
        <?php endwhile; ?>

    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
/* ============================================================
   Monthly Admissions Trend Chart
   ============================================================ */
const months = <?= json_encode($months) ?>;
const monthlyCounts = <?= json_encode($monthlyCounts) ?>;

new Chart(document.getElementById("monthlyChart"), {
    type: "line",
    data: {
        labels: months,
        datasets: [{
            label: "Admissions per Month",
            data: monthlyCounts,
            borderColor: "rgba(52, 152, 219, 0.9)",
            backgroundColor: "rgba(52, 152, 219, 0.2)",
            fill: true,
            tension: 0.35,
            borderWidth: 3,
            pointRadius: 4
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,  // PREVENT infinite scrolling
        plugins: {
            legend: { position: "bottom" },
            title: {
                display: true,
                text: "Admissions Trend by Month",
                font: { size: 18 }
            }
        },
        scales: {
            y: { beginAtZero: true },
            x: { grid: { display: false } }
        }
    }
});
</script>

<?php
// Insert into template
$content = ob_get_clean();
include "report_template.php";
