<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

include "../db.php";

$title = "Available Beds Lookup";

// Capture page content for template
ob_start();
?>

<!-- ============================= -->
<!--      BRANCH SELECTION FORM    -->
<!-- ============================= -->
<form method="POST">
    <label>Select Branch</label>
    <select name="branch_id" required>
        <option value="">-- Select Branch --</option>
        <?php
            $branches = $conn->query("SELECT branch_id, branch_name FROM Branch ORDER BY branch_name");
            while ($b = $branches->fetch_assoc()):
        ?>
            <option value="<?= $b['branch_id'] ?>">
                <?= htmlspecialchars($b['branch_name']) ?>
            </option>
        <?php endwhile; ?>
    </select>

    <input type="submit" value="View Available Beds">
</form>

<br>

<?php
// ============================
//   DISPLAY AVAILABLE BEDS
// ============================
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $branch = $_POST["branch_id"];

    $stmt = $conn->prepare("
        SELECT *
        FROM vw_available_beds
        WHERE branch_id = ?
        ORDER BY room_no, bed_number
    ");
    $stmt->bind_param("s", $branch);
    $stmt->execute();
    $result = $stmt->get_result();
?>

<!-- TABLE OUTPUT -->
<div class="table-container">
    <h2>Available Beds</h2>
    <table>
        <tr>
            <th>Bed ID</th>
            <th>Room</th>
            <th>Bed #</th>
            <th>Type</th>
            <th>Status</th>
        </tr>

        <?php while ($row = $result->fetch_assoc()): ?>
        <tr>
            <td><?= $row['bed_id'] ?></td>
            <td><?= $row['room_no'] ?></td>
            <td><?= $row['bed_number'] ?></td>
            <td><?= $row['bed_type'] ?></td>
            <td><?= $row['status'] ?></td>
        </tr>
        <?php endwhile; ?>

    </table>
</div>

<?php } ?>

<?php
// Pass content to template
$content = ob_get_clean();
include "report_template.php";
