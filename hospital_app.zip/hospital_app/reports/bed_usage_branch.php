<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}
include "../db.php";

$title = "Bed Usage (Per Branch)";
$branchData = null;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $branch_id = $_POST["branch_id"];

    $query = "SELECT * FROM vw_bed_usage WHERE branch_id = '$branch_id'";
    $result = $conn->query($query);
    $branchData = $result->fetch_assoc();
}
?>

<!DOCTYPE html>
<html>
<head>
    <title><?= $title ?></title>
    <link rel="stylesheet" href="../style.css">

    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        .chart-container {
            width: 70%;
            max-width: 600px;
            margin: 25px auto;
            padding: 20px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 0 10px rgba(0,0,0,0.15);
        }
    </style>
</head>

<body>

<h1><?= $title ?></h1>
<a href="../index.php"><button>⬅ Back</button></a>

<div class="container-box">
<form method="POST">
    <label>Select Branch</label>
    <select name="branch_id" required>
        <option value="">-- Select Branch --</option>
        <?php
            $branches = $conn->query("SELECT branch_id, branch_name FROM Branch");
            while ($b = $branches->fetch_assoc()) {
                echo "<option value='{$b['branch_id']}'>{$b['branch_name']}</option>";
            }
        ?>
    </select>
    <input type="submit" value="View Bed Usage">
</form>
</div>

<?php if ($branchData): ?>

<!-- TABLE -->
<div class="table-container">
<table>
    <tr>
        <th>Branch</th>
        <th>Available</th>
        <th>Occupied</th>
        <th>Maintenance</th>
        <th>Total</th>
    </tr>
    <tr>
        <td><?= $branchData['branch_name'] ?></td>
        <td><?= $branchData['available_beds'] ?></td>
        <td><?= $branchData['occupied_beds'] ?></td>
        <td><?= $branchData['maintenance_beds'] ?></td>
        <td><?= $branchData['total_beds'] ?></td>
    </tr>
</table>
</div>

<!-- PIE CHART -->
<div class="chart-container">
    <canvas id="bedPie"></canvas>
</div>

<script>
const data = {
    labels: ["Available", "Occupied", "Maintenance"],
    datasets: [{
        data: [
            <?= $branchData['available_beds'] ?>,
            <?= $branchData['occupied_beds'] ?>,
            <?= $branchData['maintenance_beds'] ?>
        ],
        backgroundColor: [
            "rgba(46, 204, 113, 0.85)",   // green
            "rgba(52, 152, 219, 0.85)",   // blue
            "rgba(231, 76, 60, 0.85)"     // red
        ],
        borderColor: "#fff",
        borderWidth: 2
    }]
};

new Chart(document.getElementById("bedPie"), {
    type: "pie",
    data: data,
    options: {
        responsive: true,
        plugins: {
            legend: { position: "bottom" },
            title: {
                display: true,
                text: "Bed Distribution — <?= $branchData['branch_name'] ?>",
                font: { size: 18 }
            }
        }
    }
});
</script>

<?php endif; ?>

</body>
</html>
