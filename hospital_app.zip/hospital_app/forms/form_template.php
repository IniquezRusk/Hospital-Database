<?php
// Start session only if not started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$title = isset($title) ? $title : "Form";
$content = isset($content) ? $content : "<p>Form error: No content provided.</p>";
?>

<!DOCTYPE html>
<html>
<head>
    <title><?= htmlspecialchars($title) ?> — Vital Link</title>

    <!-- Use existing global CSS -->
    <link rel="stylesheet" href="../style.css">

    <style>
        .form-wrapper {
            width: 90%;
            max-width: 800px;
            margin: 35px auto;
            padding: 25px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.12);
        }

        .form-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #eee;
            padding-bottom: 15px;
            margin-bottom: 25px;
        }

        .form-title {
            font-size: 30px;
            font-weight: bold;
            color: #2c3e50;
            margin: 0;
        }

        form label {
            font-weight: bold;
            margin-top: 10px;
            display: block;
        }

        form input, form select {
            width: 100%;
            padding: 10px;
            margin-top: 6px;
            margin-bottom: 18px;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 15px;
        }

        .success-msg {
            font-size: 18px;
            padding: 12px;
            border-radius: 8px;
            background: #dfffe0;
            color: #187530;
        }

        .error-msg {
            font-size: 18px;
            padding: 12px;
            border-radius: 8px;
            background: #ffdede;
            color: #9e1b1b;
        }
    </style>
</head>

<body>

<div class="form-wrapper">

    <div class="form-header">
        <h1 class="form-title"><?= htmlspecialchars($title) ?></h1>
        <a href="../index.php"><button>⬅ Back</button></a>
    </div>

    <!-- FORM CONTENT GOES HERE -->
    <?= $content ?>

</div>

<footer>
    <div style="text-align:center; margin-top:25px; color:#777;">
        Vital Link • Contact: <a href="mailto:VitalLink@gmail.com">VitalLink@gmail.com</a>
    </div>
</footer>

</body>
</html>
