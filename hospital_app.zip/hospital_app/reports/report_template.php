<!DOCTYPE html>
<html>
<head>
    <title><?= htmlspecialchars($title) ?> — Vital Link</title>

    <!-- Correct CSS linking -->
    <link rel="stylesheet" href="../style.css">

    <style>
        /* Extra polish for reports */
        .report-wrapper {
            width: 90%;
            max-width: 1200px;
            margin: 30px auto;
            padding: 25px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.12);
        }

        .report-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 2px solid #eee;
            padding-bottom: 15px;
            margin-bottom: 25px;
        }

        .report-title {
            font-size: 32px;
            font-weight: bold;
            color: #2c3e50;
            margin: 0;
        }

        footer {
            text-align: center;
            margin-top: 40px;
            padding: 20px;
            color: #777;
            font-size: 14px;
        }
    </style>

</head>
<body>

<div class="report-wrapper">

    <!-- Header -->
    <div class="report-header">
        <h1 class="report-title"><?= htmlspecialchars($title) ?></h1>
        <a href="../index.php"><button>⬅ Back</button></a>
    </div>

    <!-- MAIN REPORT CONTENT -->
    <div class="table-container">
        <?= $content ?>
    </div>

</div>

<footer>
    Vital Link • Contact: <a href="mailto:VitalLink@gmail.com">VitalLink@gmail.com</a>
</footer>

</body>
</html>
