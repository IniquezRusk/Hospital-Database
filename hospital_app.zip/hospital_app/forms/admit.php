<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

include "../db.php";

// Prevent MySQL SIGNAL from throwing fatal exceptions
mysqli_report(MYSQLI_REPORT_OFF);

$title = "Admit New Patient";

// Start content buffer for form_template.php
ob_start();
?>

<script>
// =======================
// LOAD DOCTORS BY BRANCH
// =======================
function loadDoctors() {
    let branch_id = document.getElementById("branch").value;

    if (branch_id === "") {
        document.getElementById("doctor").innerHTML =
            "<option value=''>-- Select Doctor --</option>";
        return;
    }

    let xhr = new XMLHttpRequest();
    xhr.open("GET", "../get_doctors.php?branch_id=" + branch_id, true);

    xhr.onload = function() {
        if (this.status === 200) {
            let doctors = JSON.parse(this.responseText);
            let dropdown = document.getElementById("doctor");

            dropdown.innerHTML = "<option value=''>-- Select Doctor --</option>";

            doctors.forEach(function(doc) {
                dropdown.innerHTML += 
                    `<option value="${doc.doctor_id}">${doc.name}</option>`;
            });
        }
    };

    xhr.send();
}
</script>

<form method="POST">

    <!-- ======================= -->
    <!-- WAITING ROOM: NEVER ADMITTED -->
    <!-- ======================= -->
    <label>Select Patient</label>
    <select name="patient_id" required>
        <option value="">-- Choose Patient --</option>

        <?php
        // Only show patients who have NEVER been admitted at all
        $patients = $conn->query("
            SELECT p.patient_id, p.name
            FROM Patient p
            LEFT JOIN Admission a ON p.patient_id = a.patient_id
            WHERE a.patient_id IS NULL
            ORDER BY p.name;
        ");

        while ($p = $patients->fetch_assoc()) {
            echo "<option value='{$p['patient_id']}'>" .
                 htmlspecialchars($p['name']) .
                 "</option>";
        }
        ?>
    </select>

    <!-- ======================= -->
    <!-- BRANCH -->
    <!-- ======================= -->
    <label>Select Branch</label>
    <select name="branch_id" id="branch" onchange="loadDoctors()" required>
        <option value="">-- Choose Branch --</option>

        <?php
        $branches = $conn->query("
            SELECT branch_id, branch_name 
            FROM Branch 
            ORDER BY branch_name;
        ");

        while ($b = $branches->fetch_assoc()) {
            echo "<option value='{$b['branch_id']}'>" .
                 htmlspecialchars($b['branch_name']) .
                 "</option>";
        }
        ?>
    </select>

    <!-- ======================= -->
    <!-- DOCTOR (Filtered by Branch) -->
    <!-- ======================= -->
    <label>Select Doctor</label>
    <select name="doctor_id" id="doctor" required>
        <option value="">-- Select Doctor --</option>
    </select>

    <!-- ======================= -->
    <!-- DIAGNOSIS -->
    <!-- ======================= -->
    <label>Reason</label>
    <input type="text" name="diagnosis" required>

    <input type="submit" value="Admit Patient">

</form>

<?php
// ===============================
// HANDLE FORM SUBMISSION
// ===============================
if ($_SERVER['REQUEST_METHOD'] === "POST") {

    $pid  = $_POST['patient_id'];
    $did  = $_POST['doctor_id'];
    $bid  = $_POST['branch_id'];
    $diag = $_POST['diagnosis'];

    $sql = "CALL sp_admit_patient($pid, '$did', '$bid', '$diag')";
    $result = $conn->query($sql);

    if ($result === TRUE) {
        echo "<div class='success-msg'>Patient successfully admitted!</div>";
    } else {
        echo "<div class='error-msg'>
                ❌ Unable to admit patient:<br>
                There are no <strong>available beds</strong> in this branch that meet the patient’s needs.
              </div>";
    }
}

$content = ob_get_clean();
include "form_template.php";
