<?php
$title = "Available Beds";
include "../db.php";

$result = $conn->query("SELECT * FROM vw_available_beds");

$table = "<table><tr>
<th>Bed ID</th><th>Room</th><th>Bed #</th>
<th>Type</th><th>Status</th><th>Branch</th>
</tr>";

while ($r = $result->fetch_assoc()) {
    $table .= "<tr>
        <td>{$r['bed_id']}</td>
        <td>{$r['room_no']}</td>
        <td>{$r['bed_number']}</td>
        <td>{$r['bed_type']}</td>
        <td>{$r['status']}</td>
        <td>{$r['branch_name']}</td>
    </tr>";
}
$table .= "</table>";

$content = $table;
include "report_template.php";
