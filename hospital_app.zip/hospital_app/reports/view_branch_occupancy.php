<?php
$title = "Branch Occupancy";
include "../db.php";

$result = $conn->query("SELECT * FROM vw_branch_occupancy");

$table = "<table><tr>
<th>Branch ID</th><th>Branch</th><th>Capacity</th>
<th>Admitted</th><th>Available</th>
</tr>";

while ($r = $result->fetch_assoc()) {
    $table .= "<tr>
        <td>{$r['branch_id']}</td>
        <td>{$r['branch_name']}</td>
        <td>{$r['total_capacity']}</td>
        <td>{$r['admitted_patients']}</td>
        <td>{$r['available_capacity']}</td>
    </tr>";
}
$table .= "</table>";

$content = $table;
include "report_template.php";
