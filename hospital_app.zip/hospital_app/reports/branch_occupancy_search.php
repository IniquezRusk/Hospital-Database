<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

include "../db.php";

$title = "Live Branch Occupancy Report";

$branchData = null;

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $branch_id = $_POST["branch_id"];

    // LIVE OCCUPANCY QUERY
    $stmt = $conn->prepare("
        SELECT 
            br.branch_name,
            br.capacity AS total_capacity,

            -- Admitted patients
            (SELECT COUNT(*) 
             FROM Admission 
             WHERE branch_id = br.branch_id 
               AND status = 'Admitted') AS admitted_patients,

            -- Beds by status
            (SELECT COUNT(*) FROM Bed WHERE branch_id = br.branch_id AND status='Available') AS available_beds,
            (SELECT COUNT(*) FROM Bed WHERE branch_id = br.branch_id AND status='Occupied') AS occupied_beds,
            (SELECT COUNT(*) FROM Bed WHERE branch_id = br.branch_id AND status='Maintenance') AS maintenance_beds,

            -- Total beds physically in the branch
            (SELECT COUNT(*) FROM Bed WHERE branch_id = br.branch_id) AS total_beds

        FROM Branch br
        WHERE br.branch_id = ?
        LIMIT 1;
    ");

    $stmt->bind_param("s", $branch_id);
    $stmt->execute();
    $branchData = $stmt->get_result()->fetch_assoc();
}

// Start capturing content for template
ob_start();
?>

<!-- ============================= -->
<!--      BRANCH SELECTION FORM    -->
<!-- ============================= -->
<form method="POST">
    <label>Select Branch</label>
    <select name="branch_id" required>
        <option value="">-- Select Branch --</option>

        <?php
            $branches = $conn->query("SELECT branch_id, branch_name FROM Branch ORDER BY branch_name");
            while ($b = $branches->fetch_assoc()):
        ?>
            <option value="<?= $b['branch_id'] ?>">
                <?= htmlspecialchars($b['branch_name']) ?>
            </option>
        <?php endwhile; ?>
    </select>

    <input type="submit" value="View Occupancy">
</form>

<br>

<?php if ($branchData): ?>

<!-- ============================= -->
<!--         DATA TABLE            -->
<!-- ============================= -->
<div class="table-container">
    <h2>Current Occupancy — <?= htmlspecialchars($branchData['branch_name']) ?></h2>

    <table>
        <tr>
            <th>Branch</th>
            <th>Total Capacity</th>
            <th>Admitted Patients</th>
            <th>Available Beds</th>
            <th>Occupied Beds</th>
            <th>Maintenance Beds</th>
            <th>Total Beds</th>
        </tr>

        <tr>
            <td><?= $branchData['branch_name'] ?></td>
            <td><?= $branchData['total_capacity'] ?></td>
            <td><?= $branchData['admitted_patients'] ?></td>
            <td><?= $branchData['available_beds'] ?></td>
            <td><?= $branchData['occupied_beds'] ?></td>
            <td><?= $branchData['maintenance_beds'] ?></td>
            <td><?= $branchData['total_beds'] ?></td>
        </tr>
    </table>
</div>

<br>

<!-- ============================= -->
<!--             CHART             -->
<!-- ============================= -->
<div class="chart-container" style="max-width:650px; margin:auto;">
    <canvas id="occupancyPie" style="height:260px;"></canvas>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
new Chart(document.getElementById("occupancyPie"), {
    type: "pie",
    data: {
        labels: ["Occupied", "Available", "Maintenance"],
        datasets: [{
            data: [
                <?= $branchData['occupied_beds'] ?>,
                <?= $branchData['available_beds'] ?>,
                <?= $branchData['maintenance_beds'] ?>
            ],
            backgroundColor: [
                "rgba(52, 152, 219, 0.85)",     // occupied
                "rgba(46, 204, 113, 0.85)",     // available
                "rgba(231, 76, 60, 0.85)"       // maintenance
            ],
            borderColor: "#fff",
            borderWidth: 2
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,  // prevents infinite page height bug
        plugins: {
            legend: { position: "bottom" },
            title: {
                display: true,
                text: "Live Bed Status — <?= htmlspecialchars($branchData['branch_name']) ?>",
                font: { size: 18 }
            }
        }
    }
});
</script>

<?php endif; ?>

<?php
// Finish and send to template
$content = ob_get_clean();
include "report_template.php";
