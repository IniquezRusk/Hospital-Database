<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}
include "../db.php";

$title = "Check Branch Capacity";
$content = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $branch = $_POST["branch_id"];

    // Execute procedure
    $result = $conn->query("CALL sp_check_branch_capacity('$branch')");

    // Fetch result
    $row = $result->fetch_assoc();

    // VERY IMPORTANT: clear stored procedure result set
    while ($conn->more_results() && $conn->next_result()) {;}

    $content .= "<table><tr>
        <th>Branch</th><th>Capacity</th><th>Occupied</th><th>Available</th>
    </tr>
    <tr>
        <td>{$row['BranchID']}</td>
        <td>{$row['Capacity']}</td>
        <td>{$row['Occupied']}</td>
        <td>{$row['Available']}</td>
    </tr>
    </table>";
}
?>

<!DOCTYPE html>
<html>
<head>
<title><?= $title ?></title>
<link rel="stylesheet" href="../style.css">
</head>
<body>

<h1><?= $title ?></h1>
<a href="../index.php"><button>⬅ Back</button></a>

<div class="container-box">
<form method="POST">
    <label>Branch</label>
    <select name="branch_id" required>
        <option value="">-- Select --</option>
        <?php
            $b = $conn->query("SELECT * FROM Branch");
            while ($br = $b->fetch_assoc()) {
                echo "<option value='{$br['branch_id']}'>{$br['branch_name']}</option>";
            }
        ?>
    </select>

    <input type="submit" value="Run Procedure">
</form>
</div>

<div class="table-container">
<?= $content ?>
</div>

</body>
</html>
