<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

include "../db.php";

$title = "Branch Load Over Time";

// Load branches
$branchRes = $conn->query("SELECT branch_id, branch_name FROM Branch ORDER BY branch_name");

// Selected branch
$selected = $_POST['branch_id'] ?? "";

// Build WHERE
$where = "";
if (!empty($selected)) {
    $safe = $conn->real_escape_string($selected);
    $where = "WHERE br.branch_id = '$safe'";
}

// Query admissions
$sql = "
    SELECT 
        br.branch_id,
        br.branch_name,
        a.admission_date,
        a.discharge_date
    FROM Branch br
    LEFT JOIN Admission a ON a.branch_id = br.branch_id
    $where
    ORDER BY a.admission_date
";
$res = $conn->query($sql);

// Build timeline
$data = [];
$dateSet = [];

while ($row = $res->fetch_assoc()) {
    if (!$row['admission_date']) continue;

    $branch = $row['branch_name'];
    $adm = strtotime($row['admission_date']);
    $disc = $row['discharge_date'] ? strtotime($row['discharge_date']) : strtotime(date("Y-m-d"));

    for ($t = $adm; $t <= $disc; $t += 86400) {
        $d = date("Y-m-d", $t);
        $dateSet[$d] = true;

        if (!isset($data[$d])) {
            $data[$d] = 0;
        }
        $data[$d]++;
    }
}

$dates = array_keys($dateSet);
sort($dates);

$values = [];
foreach ($dates as $d) {
    $values[] = $data[$d] ?? 0;
}

// ------------------------
// Build content for template
// ------------------------
ob_start();
?>

<!-- ================================ -->
<!--   BRANCH SELECTION FORM          -->
<!-- ================================ -->
<form method="POST">
    <label>Select Branch</label>
    <select name="branch_id" required>
        <option value="">-- Select Branch --</option>

        <?php while ($b = $branchRes->fetch_assoc()): ?>
            <option value="<?= $b['branch_id'] ?>" <?= ($b['branch_id'] == $selected) ? "selected" : "" ?>>
                <?= htmlspecialchars($b['branch_name']) ?>
            </option>
        <?php endwhile; ?>

    </select>
    <input type="submit" value="Show Trend">
</form>

<br>

<?php if (!empty($selected)): ?>

<!-- ================================ -->
<!--      CHART DISPLAY               -->
<!-- ================================ -->
<div class="chart-container">
    <canvas id="trendChart" style="height:300px;"></canvas>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
const labels = <?= json_encode($dates) ?>;
const values = <?= json_encode($values) ?>;

const ctx = document.getElementById("trendChart").getContext("2d");

const gradient = ctx.createLinearGradient(0, 0, 0, 250);
gradient.addColorStop(0, "rgba(52, 152, 219, 0.35)");
gradient.addColorStop(0.8, "rgba(52, 152, 219, 0.05)");
gradient.addColorStop(1, "rgba(52, 152, 219, 0)");

new Chart(ctx, {
    type: "line",
    data: {
        labels,
        datasets: [{
            label: "Active Patients",
            data: values,
            borderColor: "rgba(52,152,219,1)",
            backgroundColor: gradient,
            fill: true,
            tension: 0.5,
            borderWidth: 3,
            pointRadius: 0
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,   // ⭐ prevents infinite scroll bug
        plugins: {
            legend: { display: false },
            title: {
                display: true,
                text: "Branch Load Over Time",
                font: { size: 20 }
            }
        },
        scales: {
            y: {
                beginAtZero: true,
                grid: { color: "rgba(0,0,0,0.07)" }
            },
            x: {
                grid: { display: false }
            }
        }
    }
});
</script>

<?php endif; ?>

<?php
$content = ob_get_clean();
include "report_template.php";
