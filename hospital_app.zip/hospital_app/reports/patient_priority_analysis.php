<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}
include "../db.php";

$title = "Patient Priority Analysis";

/* --------------------------------------------------
   1) Priority Distribution (Pie Chart)
-------------------------------------------------- */
$distResult = $conn->query("SELECT * FROM vw_priority_distribution");

$priorityLabels = [];
$priorityCounts = [];

while ($row = $distResult->fetch_assoc()) {
    $priorityLabels[] = $row['priority_level'];
    $priorityCounts[] = (int)$row['total_patients'];
}

/* --------------------------------------------------
   2) Priority by Branch (Stacked Bar Chart)
-------------------------------------------------- */
$branchResult = $conn->query("SELECT * FROM vw_priority_by_branch");

$branches = [];
$priorityLevels = ['Low', 'Medium', 'High', 'Critical'];

$branchPriorityMatrix = [];

while ($row = $branchResult->fetch_assoc()) {
    $br = $row['branch_name'];
    $pl = $row['priority_level'];
    $cnt = (int)$row['total_patients'];

    if (!isset($branchPriorityMatrix[$br])) {
        $branchPriorityMatrix[$br] = [
            'Low' => 0,
            'Medium' => 0,
            'High' => 0,
            'Critical' => 0
        ];
    }
    $branchPriorityMatrix[$br][$pl] = $cnt;
}

foreach ($branchPriorityMatrix as $brName => $vals) {
    $branches[] = $brName;
}

$lowData = [];
$medData = [];
$highData = [];
$critData = [];

foreach ($branches as $brName) {
    $lowData[]  = $branchPriorityMatrix[$brName]['Low'];
    $medData[]  = $branchPriorityMatrix[$brName]['Medium'];
    $highData[] = $branchPriorityMatrix[$brName]['High'];
    $critData[] = $branchPriorityMatrix[$brName]['Critical'];
}

/* --------------------------------------------------
   3) High/Critical Detailed Table
-------------------------------------------------- */
$hpResult = $conn->query("
    SELECT *
    FROM vw_high_priority_patients
    ORDER BY admission_date DESC
");

// BUILD MAIN CONTENT FOR TEMPLATE
ob_start();
?>

<!-- ========================================== -->
<!--  TABLE FIRST                               -->
<!-- ========================================== -->
<div class="table-container">
    <h2>High & Critical Patients (Detail)</h2>
    <table>
        <tr>
            <th>Admission ID</th>
            <th>Patient</th>
            <th>Priority</th>
            <th>Bed</th>
            <th>Bed Type</th>
            <th>Branch</th>
            <th>Admission Date</th>
        </tr>
        <?php while ($r = $hpResult->fetch_assoc()): ?>
        <tr>
            <td><?= $r['admission_id'] ?></td>
            <td><?= htmlspecialchars($r['patient_name']) ?></td>
            <td><?= $r['priority_level'] ?></td>
            <td><?= $r['bed_id'] ?></td>
            <td><?= $r['bed_type'] ?></td>
            <td><?= $r['branch_name'] ?></td>
            <td><?= $r['admission_date'] ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

<br>

<!-- ========================================== -->
<!-- PIE CHART (SMALLER + FIXED SIZE)           -->
<!-- ========================================== -->
<div class="chart-container" style="max-width:600px; margin:auto;">
    <h2 style="text-align:center;">Priority Distribution</h2>
    <canvas id="priorityPie" style="height:220px;"></canvas>
</div>

<br>

<!-- ========================================== -->
<!-- STACKED BAR CHART (FIXED HEIGHT)           -->
<!-- ========================================== -->
<div class="chart-container" style="max-width:800px; margin:auto;">
    <h2 style="text-align:center;">Priority Levels by Branch</h2>
    <canvas id="priorityBranchBar" style="height:270px;"></canvas>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
// ======================
// PIE CHART (BUG FIX APPLIED)
// ======================
new Chart(document.getElementById("priorityPie"), {
    type: "pie",
    data: {
        labels: <?= json_encode($priorityLabels) ?>,
        datasets: [{
            data: <?= json_encode($priorityCounts) ?>,
            backgroundColor: [
                "rgba(52, 152, 219, 0.85)",
                "rgba(243, 156, 18, 0.85)",
                "rgba(231, 76, 60, 0.85)",
                "rgba(142, 68, 173, 0.85)"
            ],
            borderColor: "#fff",
            borderWidth: 2
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,   // ⭐ BUG FIX
        plugins: {
            legend: { position: "bottom" }
        }
    }
});

// ======================
// STACKED BAR (BUG FIX)
// ======================
new Chart(document.getElementById("priorityBranchBar"), {
    type: "bar",
    data: {
        labels: <?= json_encode($branches) ?>,
        datasets: [
            { label: "Low",      data: <?= json_encode($lowData) ?>,  backgroundColor: "rgba(52,152,219,0.85)" },
            { label: "Medium",   data: <?= json_encode($medData) ?>,  backgroundColor: "rgba(243,156,18,0.85)" },
            { label: "High",     data: <?= json_encode($highData) ?>, backgroundColor: "rgba(231,76,60,0.85)" },
            { label: "Critical", data: <?= json_encode($critData) ?>, backgroundColor: "rgba(142,68,173,0.85)" }
        ]
    },
    options: {
        responsive: true,
        maintainAspectRatio: true,   // ⭐ BUG FIX
        scales: {
            x: { stacked: true },
            y: { stacked: true, beginAtZero: true }
        },
        plugins: {
            legend: { position: "bottom" }
        }
    }
});
</script>

<?php
$content = ob_get_clean();
include "report_template.php";
