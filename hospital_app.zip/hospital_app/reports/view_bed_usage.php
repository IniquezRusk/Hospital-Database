<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}
include "../db.php";

$title = "Bed Usage Summary";
?>

<!DOCTYPE html>
<html>
<head>
<title><?= $title ?></title>
<link rel="stylesheet" href="../style.css">
</head>
<body>

<h1><?= $title ?></h1>
<a href="../index.php"><button>⬅ Back</button></a>

<div class="table-container">

<table>
<tr>
    <th>Branch ID</th>
    <th>Branch</th>
    <th>Available Beds</th>
    <th>Occupied Beds</th>
    <th>Maintenance Beds</th>
    <th>Total Beds</th>
</tr>

<?php
$result = $conn->query("SELECT * FROM vw_bed_usage");

while ($r = $result->fetch_assoc()) {
    echo "<tr>
        <td>{$r['branch_id']}</td>
        <td>{$r['branch_name']}</td>
        <td>{$r['available_beds']}</td>
        <td>{$r['occupied_beds']}</td>
        <td>{$r['maintenance_beds']}</td>
        <td>{$r['total_beds']}</td>
    </tr>";
}
?>

</table>
</div>

</body>
</html>
