<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
include "db.php";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Vital Link | Hospital Admissions Dashboard</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

<!-- ========================= HEADER ========================= -->
<header class="header">
    <div class="header-title">Vital Link — Hospital Admissions System</div>
    <div class="header-user">
        Logged in as: <strong><?= $_SESSION['username'] ?></strong>
        <a href="logout.php" class="logout-btn">Logout</a>
    </div>
</header>

<!-- ========================= MAIN WRAPPER ========================= -->
<div class="dashboard-container">

    <!-- ===== ACTIONS ===== -->
    <section class="dashboard-section">
        <h2>Actions</h2>

        <div class="card-grid">

            <a class="card" href="forms/admit.php">
                <h3>Admit New Patient</h3>
                <p>Register a new patient admission</p>
            </a>

            <a class="card" href="forms/discharge.php">
                <h3>Discharge Patient</h3>
                <p>Process and finalize patient discharge</p>
            </a>

            <a class="card" href="forms/add_patient.php">
                <h3>Add New Patient</h3>
                <p>Register a new patient record</p>
            </a>

            <a class="card" href="forms/manage_beds.php">
                <h3>Maintenance Check</h3>
                <p>Maintain bed status and availability</p>
            </a>

        </div>
    </section>

    <!-- ===== REPORTS ===== -->
    <section class="dashboard-section">
        <h2>Reports</h2>

        <div class="card-grid">

            <a class="card" href="reports/available_beds_search.php">
                <h3>Available Beds</h3>
                <p>View real-time bed availability</p>
            </a>

            <a class="card" href="reports/view_doctor_load.php">
                <h3>Doctor Load</h3>
                <p>Analyze patient load for each doctor</p>
            </a>

            <a class="card" href="reports/view_current_admissions.php">
                <h3>Current Admissions</h3>
                <p>Track current admissions by department</p>
            </a>

            <a class="card" href="reports/longest_stays.php">
                <h3>Length of Admission</h3>
                <p>Track length of admission by department</p>
            </a>

        </div>
    </section>

    <!-- ===== ANALYSIS ===== -->
    <section class="dashboard-section">
        <h2>Analysis</h2>

        <div class="card-grid">

            <a class="card" href="reports/view_admission_history.php">
                <h3>Admission History</h3>
                <p>Full historical patient admission records</p>
            </a>

            <a class="card" href="reports/branch_occupancy_search.php">
                <h3>Branch Occupancy</h3>
                <p>Track bed usage by department</p>
            </a>

            <a class="card" href="reports/branch_load_over_time.php">
                <h3>Branch Load Over Time</h3>
                <p>Track branch load over time</p>
            </a>

            <a class="card" href="reports/patient_priority_analysis.php">
                <h3>Priority Analysis</h3>
                <p>Review patient priority distribution</p>
            </a>

        </div>
    </section>

</div>

<!-- ========================= FOOTER ========================= -->
<footer class="footer">
    <div>© <?= date("Y") ?> Vital Link Hospital System</div>
    <div>Contact: <a href="mailto:VitalLink@gmail.com">VitalLink@gmail.com</a></div>
</footer>

</body>
</html>
