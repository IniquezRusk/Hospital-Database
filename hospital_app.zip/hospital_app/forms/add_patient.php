<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

include "../db.php";

$title = "Add New Patient";

// =======================================================
// Begin collecting form content for form_template.php
// =======================================================
ob_start();
?>

<form method="POST">

    <label>Full Name</label>
    <input type="text" name="name" required>

    <label>Gender</label>
    <select name="gender" required>
        <option value="">-- Select Gender --</option>
        <option>Male</option>
        <option>Female</option>
        <option>Other</option>
    </select>

    <label>Age</label>
    <input type="number" name="age" min="0" max="120" required>

    <label>Priority Level</label>
    <select name="priority_level" required>
        <option value="">-- Select Priority --</option>
        <option>Low</option>
        <option>Medium</option>
        <option>High</option>
        <option>Critical</option>
    </select>

    <label>Phone Number</label>
    <input type="text" name="phone" required>

    <label>Address</label>
    <input type="text" name="address" required>

    <input type="submit" value="Add Patient">

</form>

<?php
// =======================================================
// Form Submission Handler
// =======================================================
if ($_SERVER['REQUEST_METHOD'] === "POST") {

    $name     = $_POST['name'];
    $gender   = $_POST['gender'];
    $age      = $_POST['age'];
    $priority = $_POST['priority_level'];
    $phone    = $_POST['phone'];
    $address  = $_POST['address'];

    $stmt = $conn->prepare("
        INSERT INTO Patient (name, gender, age, priority_level, phone, address)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmt->bind_param("ssisss", $name, $gender, $age, $priority, $phone, $address);

    if ($stmt->execute()) {
        echo "<div class='success-msg'>Patient successfully added!</div>";
    } else {
        echo "<div class='error-msg'>Error: " . $stmt->error . "</div>";
    }
}

$content = ob_get_clean();
include "form_template.php";
