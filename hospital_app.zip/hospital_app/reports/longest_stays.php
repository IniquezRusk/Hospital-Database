<?php
// Start session only if not active
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

include "../db.php";

$title = "Longest-Staying Patients";

// -----------------------------
// Load branch list for dropdown
// -----------------------------
$branches = $conn->query("SELECT branch_id, branch_name FROM Branch ORDER BY branch_name");

// -----------------------------
// Fetch filtered report data
// -----------------------------
$selected_branch = "";
$stmt = null;

if ($_SERVER["REQUEST_METHOD"] === "POST" && !empty($_POST["branch_id"])) {

    $selected_branch = $_POST["branch_id"];

    $stmt = $conn->prepare("
        SELECT 
            a.admission_id,
            p.name AS patient_name,
            br.branch_name,
            d.name AS doctor_name,
            a.admission_date,
            IFNULL(a.discharge_date, CURDATE()) AS end_date,
            DATEDIFF(
                IFNULL(a.discharge_date, CURDATE()),
                a.admission_date
            ) AS days_stayed,
            a.status,
            a.diagnosis
        FROM Admission a
        JOIN Patient p ON p.patient_id = a.patient_id
        JOIN Doctor d ON d.doctor_id = a.doctor_id
        JOIN Branch br ON br.branch_id = a.branch_id
        WHERE a.branch_id = ?
        ORDER BY days_stayed DESC
    ");
    $stmt->bind_param("s", $selected_branch);
    $stmt->execute();
    $result = $stmt->get_result();

} else {
    // Default: ALL branches
    $result = $conn->query("
        SELECT 
            a.admission_id,
            p.name AS patient_name,
            br.branch_name,
            d.name AS doctor_name,
            a.admission_date,
            IFNULL(a.discharge_date, CURDATE()) AS end_date,
            DATEDIFF(
                IFNULL(a.discharge_date, CURDATE()),
                a.admission_date
            ) AS days_stayed,
            a.status,
            a.diagnosis
        FROM Admission a
        JOIN Patient p ON p.patient_id = a.patient_id
        JOIN Doctor d ON d.doctor_id = a.doctor_id
        JOIN Branch br ON br.branch_id = a.branch_id
        ORDER BY days_stayed DESC
    ");
}

// ---------------------------------------------
// Build the table HTML
// ---------------------------------------------
$table = "<form method='POST'>
    <label>Select Branch</label>
    <select name='branch_id'>
        <option value=''>-- All Branches --</option>";

$result_branches = $conn->query("SELECT branch_id, branch_name FROM Branch ORDER BY branch_name");
while ($b = $result_branches->fetch_assoc()) {
    $sel = ($b['branch_id'] === $selected_branch) ? 'selected' : '';
    $table .= "<option value='{$b['branch_id']}' $sel>{$b['branch_name']}</option>";
}

$table .= "</select>
    <input type='submit' value='Filter'>
</form><br>";

// ⭐ WRAP TABLE FOR CSS BORDERS
$table .= "<div class='table-container'>";

$table .= "<table>
<tr>
<th>ID</th>
<th>Patient</th>
<th>Branch</th>
<th>Doctor</th>
<th>Admit Date</th>
<th>End Date</th>
<th>Days Stayed</th>
<th>Status</th>
<th>Diagnosis</th>
</tr>";

while ($row = $result->fetch_assoc()) {
    $table .= "<tr>
        <td>{$row['admission_id']}</td>
        <td>" . htmlspecialchars($row['patient_name']) . "</td>
        <td>{$row['branch_name']}</td>
        <td>" . htmlspecialchars($row['doctor_name']) . "</td>
        <td>{$row['admission_date']}</td>
        <td>{$row['end_date']}</td>
        <td>{$row['days_stayed']}</td>
        <td>{$row['status']}</td>
        <td>" . htmlspecialchars($row['diagnosis']) . "</td>
    </tr>";
}

$table .= "</table></div>"; // <-- CLOSE WRAPPER

$content = $table;

include "report_template.php";
?>
