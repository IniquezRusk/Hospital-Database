<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

include "../db.php";

$title = "Current Admissions";

// Load branch list
$branchList = $conn->query("SELECT branch_name FROM Branch ORDER BY branch_name");

// Fetch filtered results
$branchData = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['branch_name'])) {
    $branch_name = $_POST['branch_name'];

    $stmt = $conn->prepare("
        SELECT *
        FROM vw_current_admissions
        WHERE branch_name = ?
    ");
    $stmt->bind_param("s", $branch_name);
    $stmt->execute();
    $branchData = $stmt->get_result();
}

// ---------------------------------------------
// Build the content HTML (sent into template)
// ---------------------------------------------
ob_start(); // start capturing output
?>

<form method="POST">
    <label>Select Branch</label>
    <select name="branch_name" required>
        <option value="">-- Select Branch --</option>

        <?php while ($b = $branchList->fetch_assoc()): ?>
            <option value="<?= htmlspecialchars($b['branch_name']) ?>">
                <?= htmlspecialchars($b['branch_name']) ?>
            </option>
        <?php endwhile; ?>

    </select>
    <input type="submit" value="View Admissions">
</form>

<br>

<?php if ($branchData): ?>
<div class="table-container">
<table>
    <tr>
        <th>ID</th>
        <th>Patient</th>
        <th>Priority</th>
        <th>Doctor</th>
        <th>Room</th>
        <th>Bed</th>
        <th>Type</th>
        <th>Branch</th>
        <th>Date</th>
        <th>Diagnosis</th>
    </tr>

    <?php while ($row = $branchData->fetch_assoc()): ?>
        <tr>
            <td><?= $row['admission_id'] ?></td>
            <td><?= htmlspecialchars($row['patient_name']) ?></td>
            <td><?= $row['priority_level'] ?></td>
            <td><?= htmlspecialchars($row['doctor_name']) ?></td>
            <td><?= $row['room_no'] ?></td>
            <td><?= $row['bed_id'] ?></td>
            <td><?= $row['bed_type'] ?></td>
            <td><?= htmlspecialchars($row['branch_name']) ?></td>
            <td><?= $row['admission_date'] ?></td>
            <td><?= htmlspecialchars($row['diagnosis']) ?></td>
        </tr>
    <?php endwhile; ?>

</table>
</div>
<?php endif; ?>

<?php
// Finish capturing output
$content = ob_get_clean();

// Send content into the template
include "report_template.php";
