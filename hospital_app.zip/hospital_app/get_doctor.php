<?php
include "db.php";

$branch_id = $_GET['branch_id'];

$result = $conn->query("SELECT doctor_id, name FROM Doctor WHERE branch_id = '$branch_id'");

$doctors = [];

while ($row = $result->fetch_assoc()) {
    $doctors[] = $row;
}

echo json_encode($doctors);
?>
