<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

include "../db.php";

$title = "Manage Beds (Maintenance Mode)";

// Capture output for the template
ob_start();
?>

<!-- ========================= -->
<!-- Branch Selector Form -->
<!-- ========================= -->
<form method="POST">
    <label>Select Branch</label>
    <select name="branch_id" required>
        <option value="">-- Select Branch --</option>
        <?php
            $res = $conn->query("SELECT branch_id, branch_name FROM Branch ORDER BY branch_name");
            while ($row = $res->fetch_assoc()) {
                $sel = (isset($_POST['branch_id']) && $_POST['branch_id'] == $row['branch_id']) ? "selected" : "";
                echo "<option value='{$row['branch_id']}' $sel>{$row['branch_name']}</option>";
            }
        ?>
    </select>

    <input type="submit" name="load_beds" value="Load Beds">
</form>

<?php
// =========================
// When a branch is selected
// =========================

if (isset($_POST['load_beds']) && !empty($_POST['branch_id'])) {

    $branch = $_POST['branch_id'];

    $beds = $conn->query("
        SELECT *
        FROM Bed
        WHERE branch_id = '$branch'
        ORDER BY room_no, bed_number
    ");

    echo "<div class='table-container'>
            <table>
            <tr>
                <th>Bed ID</th>
                <th>Room</th>
                <th>Bed #</th>
                <th>Type</th>
                <th>Status</th>
                <th>Action</th>
            </tr>";

    while ($b = $beds->fetch_assoc()) {

        echo "<tr>
            <td>{$b['bed_id']}</td>
            <td>{$b['room_no']}</td>
            <td>{$b['bed_number']}</td>
            <td>{$b['bed_type']}</td>
            <td>{$b['status']}</td>
            <td class='action-cell'>
                <form method='POST' class='inline-form'>
                    <input type='hidden' name='branch_id' value='$branch'>
                    <input type='hidden' name='bed_id' value='{$b['bed_id']}'>
                    <input type='submit' name='set_maintenance' value='Maintenance' class='small-btn'>
                </form>

                <form method='POST' class='inline-form'>
                    <input type='hidden' name='branch_id' value='$branch'>
                    <input type='hidden' name='bed_id' value='{$b['bed_id']}'>
                    <input type='submit' name='set_available' value='Available' class='small-btn green-btn'>
                </form>
            </td>
        </tr>";
    }

    echo "</table></div>";
}

// =========================
// Status update actions
// =========================

if (isset($_POST['set_maintenance'])) {
    $bed = $_POST['bed_id'];
    $conn->query("UPDATE Bed SET status='Maintenance' WHERE bed_id='$bed'");
    echo "<div class='success-msg'>Bed set to Maintenance</div>";
}

if (isset($_POST['set_available'])) {
    $bed = $_POST['bed_id'];
    $conn->query("UPDATE Bed SET status='Available' WHERE bed_id='$bed'");
    echo "<div class='success-msg'>Bed set to Available</div>";
}

$content = ob_get_clean();
include "form_template.php";
