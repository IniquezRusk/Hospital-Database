<?php
$title = "Doctor Load";
include "../db.php";

// Load list of branches for dropdown
$branchList = $conn->query("SELECT branch_id, branch_name FROM Branch ORDER BY branch_name");

// Check filter
$selected_branch = "";
$stmt = null;

if ($_SERVER["REQUEST_METHOD"] === "POST" && !empty($_POST["branch_id"])) {
    $selected_branch = $_POST["branch_id"];

    $stmt = $conn->prepare("
        SELECT *
        FROM vw_doctor_load
        WHERE branch_name = (
            SELECT branch_name FROM Branch WHERE branch_id = ?
        )
        ORDER BY doctor_name
    ");
    $stmt->bind_param("s", $selected_branch);
    $stmt->execute();
    $result = $stmt->get_result();

} else {
    // No filter → load all
    $result = $conn->query("
        SELECT *
        FROM vw_doctor_load
        ORDER BY branch_name, doctor_name
    ");
}

// Build table HTML
$content = "<form method='POST'>
    <label>Select Branch</label>
    <select name='branch_id'>
        <option value=''>-- All Branches --</option>";

while ($b = $branchList->fetch_assoc()) {
    $sel = ($b['branch_id'] == $selected_branch) ? "selected" : "";
    $content .= "<option value='{$b['branch_id']}' $sel>{$b['branch_name']}</option>";
}

$content .= "</select>
    <input type='submit' value='Filter'>
</form><br>";

$content .= "<table>
<tr>
    <th>Doctor ID</th>
    <th>Doctor</th>
    <th>Branch</th>
    <th>Active Patients</th>
</tr>";

while ($r = $result->fetch_assoc()) {
    $content .= "<tr>
        <td>{$r['doctor_id']}</td>
        <td>" . htmlspecialchars($r['doctor_name']) . "</td>
        <td>{$r['branch_name']}</td>
        <td>{$r['active_patients']}</td>
    </tr>";
}

$content .= "</table>";

include "report_template.php";
?>
